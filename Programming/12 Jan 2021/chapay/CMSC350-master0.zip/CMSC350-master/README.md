# CMSC 350: Data Structures and Analysis

* Project 1 - Evaluate infix expressions
* Project 2 - Evaluate postfix expressions
* Project 3 - Binary Search Tree sort
* Project 4 - Java class compiler (graph example)

package com.jcaseydev;

/////////////////////////////
// Filename: ContainsCycleException.java
// Author: Justin Casey
// Data: 10 Oct 2019
//
// Exception class for when the given file
// contains a cycle

class ContainsCycleException extends Exception {

  ContainsCycleException() {
  }
}

public class Egg {
    private int pricePerDozen;//in cents! For example, $6.45 is represented by 645.
    private String name;//e.g. free range large egg
    private int count;//e.g. 10 eggs
}

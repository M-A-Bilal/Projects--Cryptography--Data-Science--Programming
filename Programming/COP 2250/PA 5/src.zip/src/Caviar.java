public class Caviar {
    private int pricePerOunce;//in cents! For example, $56.75 is represented by 5675.
    private String name;//e.g. Caspian five-star Caviar!
    private double weightInOunce;//e.g. 3.5 Ozs

}

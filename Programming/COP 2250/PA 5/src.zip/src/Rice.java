public class Rice {
    private int pricePerPound;//in cents! For example, $2.45 is represented by 245.
    private String name;//e.g. Indian Basmati Rice
    private int numberOfBags;//Rice is sold in bags of size 10lbs.
}

public class Meat {
    private int pricePerPound;//in cents! For example, $2.45 is represented by 245.
    private String name;//e.g. organic tenderlion beaf
    private double weight;//Meat is sold by weight.
}

public class Bread {
    private int pricePerLoaf;//in cents! For example, $2.45 is represented by 245.
    private String name;//e.g. French baguette
    private int count;//bread is sold by number of loaves.
}

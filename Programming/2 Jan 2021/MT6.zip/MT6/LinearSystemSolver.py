import numpy as np


def read_system(filename):
    return -1


def solve_system(A, b):
    return -1


def main():
    """
    The code given here is for you test your functions. You can modify
    it to perform more tests. When submitting, make sure the code you
    leave under main() does not cause a syntax error.
    """
    inputFname = "eq1.txt"
    #unknown_names, A, b = read_system(inputFname)
    #print("unknown names:" + str(unknown_names))
    #print("A:")
    #print(A)
    #print("b:")
    #print(b)
    #solution = solve_system(A,b)
    #print(solution)
    
    
    
################################################################ 
"""
DO NOT EDIT BELOW THIS LINE
"""
if __name__ == '__main__':
    main()
import numpy as np
import matplotlib.pyplot as plt


def func1(n):
    return -1


def func2(n):
    pass    
        

def main():
    """
    The code given here is for you test your functions. You can modify
    it to perform more tests. When submitting, make sure the code you
    leave under main() does not cause a syntax error.
    """
    print(func1(5))
    #print(func1(8))
    #func2(20)

    
    
    
################################################################ 
"""
DO NOT EDIT BELOW THIS LINE
"""
if __name__ == '__main__':
    main()
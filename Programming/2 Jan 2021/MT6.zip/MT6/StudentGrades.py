import numpy as np
import matplotlib.pyplot as plt


def read_data(filename):
    return -1


def calc_variance(data, col_name):
    return -1.0


def course_grade_average(data):
    return -1.0


def plot_stats_and_fit(data, item):
    pass
    

def main():
    """
    The code given here is for you test your functions. You can modify
    it to perform more tests. When submitting, make sure the code you
    leave under main() does not cause a syntax error.
    """
    data = read_data("student_grades.txt")
    #print(data)
    #print(calc_variance(data, "hw2"))
    #print(course_grade_average(data))
    #plot_stats_and_fit(data, 1)
    
    
    
################################################################ 
"""
DO NOT EDIT BELOW THIS LINE
"""
if __name__ == '__main__':
    main()